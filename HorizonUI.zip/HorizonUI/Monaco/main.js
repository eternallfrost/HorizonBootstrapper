var editor;

require(["vs/editor/editor.main"], () => {
    // Sample proposals (ensure this array is defined and populated as needed)
    const Proposals = [
        
    ];

    function getDependencyProposals(currentWord) {
        // Filter proposals based on the current word
        const filteredProposals = Proposals.filter(proposal => 
            proposal.label.startsWith(currentWord)
        );
        return { suggestions: filteredProposals };
    }

    monaco.languages.registerCompletionItemProvider('lua', {
        provideCompletionItems: function (model, position) {
            // Get the current word being typed
            const wordInfo = model.getWordUntilPosition(position);
            const currentWord = wordInfo.word;

            // Return filtered proposals
            return getDependencyProposals(currentWord);
        }
    });

    monaco.editor.defineTheme('horizon-dark', {
        base: 'vs-dark',
        inherit: true,
        colors: {
            "editor.background": '#24272E',
            "editorLineNumber.foreground": "#959AA7",
            "editorLineNumber.activeForeground": "#c1cce8",
            'editor.foreground': '#b2bad1',
            'editorCursor.foreground': '#a0a7ba'
        },
        rules: [
            { token: 'global', foreground: '67c1e6', fontStyle: "bold" },
            { token: 'keyword', foreground: 'f75467', fontStyle: "bold" },
            { token: 'comment', foreground: '0a9900' },
            { token: 'number', foreground: 'f99157' },
            { token: 'string', foreground: '8fe38a' },
            { token: 'Method', foreground: 'ffa1dc' }
        ]
    });

    editor = monaco.editor.create(document.getElementById("container"), {
        value: "print(\"Hello, HorizonUI!\")",
        language: "lua",
        theme: "horizon-dark",
        acceptSuggestionOnEnter: "smart",
        automaticLayout: true,
        suggestSelection: "recentlyUsed",
        suggestOnTriggerCharacters: true,
        folding: true,
        wordBasedSuggestions: true,
        scrollbar: {
            verticalHasArrows: true,
        },
        dragAndDrop: true,
        links: true,
        minimap: {
            enabled: true,
        },
        showFoldingControls: "always",
        smoothScrolling: true,
        cursorSmoothCaretAnimation: true,
        cursorBlinking: "smooth",
    });

    function AddIntellisense(label, kind, documentation, insertText) {
        var type;
        switch (kind) {
            case "Class": type = monaco.languages.CompletionItemKind.Class; break;
            case "Color": type = monaco.languages.CompletionItemKind.Color; break;
            case "Constructor": type = monaco.languages.CompletionItemKind.Constructor; break;
            case "Enum": type = monaco.languages.CompletionItemKind.Enum; break;
            case "Field": type = monaco.languages.CompletionItemKind.Field; break;
            case "File": type = monaco.languages.CompletionItemKind.File; break;
            case "Folder": type = monaco.languages.CompletionItemKind.Folder; break;
            case "Function": type = monaco.languages.CompletionItemKind.Function; break;
            case "Interface": type = monaco.languages.CompletionItemKind.Interface; break;
            case "Keyword": type = monaco.languages.CompletionItemKind.Keyword; break;
            case "Method": type = monaco.languages.CompletionItemKind.Method; break;
            case "Module": type = monaco.languages.CompletionItemKind.Module; break;
            case "Property": type = monaco.languages.CompletionItemKind.Property; break;
            case "Reference": type = monaco.languages.CompletionItemKind.Reference; break;
            case "Snippet": type = monaco.languages.CompletionItemKind.Snippet; break;
            case "Text": type = monaco.languages.CompletionItemKind.Text; break;
            case "Unit": type = monaco.languages.CompletionItemKind.Unit; break;
            case "Value": type = monaco.languages.CompletionItemKind.Value; break;
            case "Variable": type = monaco.languages.CompletionItemKind.Variable; break;
            default: type = monaco.languages.CompletionItemKind.Text; break;
        }

        Proposals.push({
            label: label,
            kind: type,
            documentation: documentation,
            insertText: insertText
        });
    }

    async function load() {
        var docs = await (await fetch('https://raw.githubusercontent.com/quivings/Solara/main/Storage/docs.txt')).json();

        for (var prop in docs) {
            for (var item in docs[prop]) {
                const document = docs[prop][item];
                AddIntellisense(document.label, document.type, document.description, document.insert);
            }
        }

        const keywords = ["_G", "_VERSION", "Enum", "game", "plugin", "shared", "script", "workspace", "DebuggerManager", "elapsedTime", "LoadLibrary", "PluginManager", "settings", "tick", "time", "typeof", "UserSettings", "HumanoidRootPart"];
        keywords.forEach(key => AddIntellisense(key, "Keyword", key, key));

        const variables = ["and", "break", "do", "else", "elseif", "end", "false", "for", "function", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while"];
        variables.forEach(variable => AddIntellisense(variable, "Variable", variable, variable));

        const methods = ["math.abs", "math.acos", "math.asin", "math.atan", "math.atan2", "math.ceil", "math.cos", "math.cosh", "math.deg", "math.exp", "math.floor", "math.fmod", "math.frexp", "math.huge", "math.ldexp", "math.log", "math.max", "math.min", "math.modf", "math.pi", "math.pow", "math.rad", "math.random", "math.randomseed", "math.sin", "math.sinh", "math.sqrt", "math.tan", "math.tanh", "table.concat", "table.foreach", "table.foreachi", "table.sort", "table.insert", "table.remove", "Color3.new", "Instance.new", "BrickColor.new", "Vector3.new", "Vector2.new", "debug.getinfo", "string.byte", "string.char", "string.dump", "string.find", "string.format", "string.gmatch", "string.gsub", "string.len", "string.lower", "string.match", "string.rep", "string.reverse", "string.sub", "string.upper", "coroutine.create", "coroutine.resume", "coroutine.running", "coroutine.status", "coroutine.wrap", "coroutine.yield"];
        methods.forEach(method => AddIntellisense(method, "Method", method, method));

        const classes = ["Drawing", "debug", "Instance", "Color3", "Vector3", "Vector2", "BrickColor", "math", "table", "string", "coroutine", "Humanoid", "ClickDetector", "LocalScript", "Model", "ModuleScript", "Mouse", "Part", "Script", "Tool", "RunService", "UserInputService", "Workspace", "ReplicatedFirst", "SoundService", "Character", "CoreGui", "ReplicatedStorage", "Lighting", "Players", "PlayerGui", "PlayerScript", "LocalPlayer", "Parent"];
        classes.forEach(className => AddIntellisense(className, "Class", className, className));

        const functions = ["print", "warn", "wait", "info", "printidentity", "assert", "collectgarbage", "error", "getfenv", "getmetatable", "setmetatable", "ipairs", "loadfile", "loadstring", "newproxy", "next", "pairs", "pcall", "spawn", "rawequal", "rawget", "rawset", "select", "tonumber", "tostring", "type", "unpack", "xpcall", "delay", "stats", ":Remove()", ":BreakJoints()", ":GetChildren()", ":FindFirstChild()", ":FireServer()", ":InvokeServer()", ":ClearAllChildren()", ":Clone()", ":Destroy()", ":FindFirstAncestor()", ":FindFirstAncestorOfClass()", ":FindFirstAncestorWhichIsA()", ":FindFirstChildOfClass()", ":FindFirstChildWhichIsA()", ":GetDebugId()", ":GetDescendants()", ":GetFullName()", ":IsA()", ":GetPropertyChangedSignal()", ":IsAncestorOf()", ":IsDescendantOf()", ":WaitForChild()", ":Connect()", ":AncestryChanged()", ":Changed()", ":ChildAdded()", ":ChildRemoved()", ":DescendantAdded()", ":DescendantRemoving()", ":GetService()", ":GetObjects()", ":HttpGet()", ":Wait()"];
        functions.forEach(func => AddIntellisense(func, "Function", func, func.includes(":") ? func.substring(1, func.length) : func));

        const properties = ["Visible", "Color", "Transparency", "Thickness", "From", "To", "Text", "Size", "Center", "Outline", "OutlineColor", "Position", "TextBounds", "Font", "Data", "Rounding", "NumSides", "Radius", "Filled", "PointA", "PointB", "PointC", "PointD"];
        properties.forEach(property => AddIntellisense(property, "Property", "Property for Drawing Library", property));
    }

    load();

    Refresh = function () {
        var text = getValue();
        setValue('');
        editor.trigger('keyboard', 'type', {
            text: text
        });
    }

    window.editorInstance = editor;
});

function getValue() {
    return editor.getValue();
}

function setValue(value) {
    editor.setValue(value);
}